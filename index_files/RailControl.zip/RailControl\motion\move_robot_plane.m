function d_motor = move_robot_plane(start_pos, end_pos, deltax, deltay, J, s, timeout_s)
% ================== move_robot_plane.m ==================
% 将网格坐标位移转换为机械三轴位移，并通过串口发送运动命令
%
% 输入：
%   start_pos : 起点网格索引 [iy, ix]
%   end_pos   : 终点网格索引 [iy, ix]
%   deltax    : x 方向网格间距，单位 m
%   deltay    : y 方向网格间距，单位 m
%   J         : 2 x 3 机械坐标到平面坐标映射矩阵
%   s         : serialport 对象
%   timeout_s : 等待 DONE 的超时时间
%
% 输出：
%   d_motor   : 实际发送的三轴位移 [dx; dy; dz]，单位 mm

if nargin < 7 || isempty(timeout_s)
    timeout_s = 60;
end

%% 网格位移 -> 平面物理位移
drow = end_pos(1) - start_pos(1);
dcol = end_pos(2) - start_pos(2);

dX_mm = dcol * deltax * 1000;
dY_mm = drow * deltay * 1000;

d_plane = [dX_mm; dY_mm];

%% 平面位移 -> 机械三轴位移
lambda = 0.0;

if lambda > 0
    d_motor = (J.' * J + lambda * eye(3)) \ (J.' * d_plane);
else
    d_motor = pinv(J) * d_plane;
end

%% 小位移归零并取整
tol_mm = 1;

d_motor(abs(d_motor) < tol_mm) = 0;
d_motor = round(d_motor);

%% 发送运动命令
cmds = {'x%d', 'y%d', 'z%d'};

for k = 1:3
    if d_motor(k) ~= 0
        cmd = sprintf(cmds{k}, d_motor(k));
        serial_wait_ack(s, cmd, "DONE", timeout_s);
        pause(0.1);
    end
end

end