function deviceWriter = init_bk_writer(soundcard_cfg, play_ch)
% ================== init_bk_writer.m ==================
% 初始化 BK 模式下只播放用的 audioDeviceWriter
%
% 输入：
%   soundcard_cfg.fs
%   soundcard_cfg.frmlen
%   soundcard_cfg.driver
%   soundcard_cfg.device
%   play_ch
%
% 输出：
%   deviceWriter : audioDeviceWriter 对象

%% 参数检查
if ~isfield(soundcard_cfg, 'fs')
    error('soundcard_cfg.fs 未设置');
end

if ~isfield(soundcard_cfg, 'frmlen')
    error('soundcard_cfg.frmlen 未设置');
end

if ~isfield(soundcard_cfg, 'driver')
    soundcard_cfg.driver = 'ASIO';
end

if ~isfield(soundcard_cfg, 'device')
    soundcard_cfg.device = '';
end

if nargin < 2 || isempty(play_ch)
    play_ch = 2;
end

%% 初始化播放设备
if strlength(string(soundcard_cfg.device)) > 0
    deviceWriter = audioDeviceWriter( ...
        'SampleRate', soundcard_cfg.fs, ...
        'Driver',     soundcard_cfg.driver, ...
        'Device',     soundcard_cfg.device, ...
        'BufferSize', soundcard_cfg.frmlen);
else
    deviceWriter = audioDeviceWriter( ...
        'SampleRate', soundcard_cfg.fs, ...
        'Driver',     soundcard_cfg.driver, ...
        'BufferSize', soundcard_cfg.frmlen);
end

setup(deviceWriter, zeros(soundcard_cfg.frmlen, play_ch));

info(deviceWriter);

fprintf('Audio interface connected for BK measurement.\n');
fprintf('SampleRate = %d Hz\n', soundcard_cfg.fs);
fprintf('FrameLen   = %d\n', soundcard_cfg.frmlen);
fprintf('Play Ch    = %d\n', play_ch);

end