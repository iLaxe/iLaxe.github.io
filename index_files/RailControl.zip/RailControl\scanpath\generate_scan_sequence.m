function scan_sequence = generate_scan_sequence(mode, x_points, y_points, map, varargin)
% ================== generate_scan_sequence.m ==================
% 根据扫描模式生成扫描点序列
%
% 支持模式：
%   'snake'
%   'circle'
%   'circle_densemid'
%   'circle_2step'
%   'custom_points'
%
% 输出：
%   scan_sequence : 每行为 [iy, ix]

ny = length(y_points);
nx = length(x_points);

switch lower(mode)

    case 'snake'

        scan_sequence = [];

        for iy = 1:ny
            if mod(iy, 2) == 1
                ix_range = 1:nx;
            else
                ix_range = nx:-1:1;
            end

            for ix = ix_range
                if map(iy, ix) == 1
                    scan_sequence = [scan_sequence; iy, ix]; %#ok<AGROW>
                end
            end
        end

    case 'circle'

        center = varargin{1};
        r      = varargin{2};
        N      = varargin{3};

        if numel(varargin) >= 4
            tol = varargin{4};
        else
            tol = 0.015;
        end

        x0 = center(1);
        y0 = center(2);

        theta = linspace(pi, 0, N);

        x_curve = x0 + r * cos(theta);
        y_curve = y0 + r * sin(theta);

        scan_sequence = map_curve_to_grid( ...
            x_curve, y_curve, x_points, y_points, map, tol);

    case 'circle_densemid'

        center = varargin{1};
        r      = varargin{2};
        N      = varargin{3};

        if numel(varargin) >= 4
            tol = varargin{4};
        else
            tol = 0.015;
        end

        x0 = center(1);
        y0 = center(2);

        u  = linspace(0, 1, N);
        u2 = 0.5 + 0.5 * sin(pi * (u - 0.5));

        theta = pi * (1 - u2);

        x_curve = x0 + r * cos(theta);
        y_curve = y0 + r * sin(theta);

        scan_sequence = map_curve_to_grid( ...
            x_curve, y_curve, x_points, y_points, map, tol);

    case 'circle_2step'

        center          = varargin{1};
        radius          = varargin{2};
        theta_mid_deg   = varargin{3};
        dtheta_mid_deg  = varargin{4};
        dtheta_side_deg = varargin{5};

        if numel(varargin) >= 6
            tol = varargin{6};
        else
            tol = 0.015;
        end

        scan_sequence = gen_circle_2step( ...
            x_points, y_points, map, ...
            center, radius, ...
            theta_mid_deg, dtheta_mid_deg, dtheta_side_deg, tol);

    case 'custom_points'

        custom_xy = varargin{1};
        tol       = varargin{2};

        scan_sequence = custom_points_to_grid( ...
            custom_xy, x_points, y_points, map, tol);

    otherwise

        error('未知扫描模式 "%s"', mode);
end

end