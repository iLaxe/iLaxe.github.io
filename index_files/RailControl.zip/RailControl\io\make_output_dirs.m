function io = make_output_dirs(io_cfg)
% ================== make_output_dirs.m ==================
% 创建数据目录和进度目录
%
% 输入：
%   io_cfg.data_root : 数据根目录，用于保存 wav 和 meta
%   io_cfg.prog_root : 进度根目录，用于保存 latest_field.png
%
% 输出：
%   io.nowStr        : 当前时间字符串
%   io.data_dir      : 数据目录
%   io.prog_dir      : 进度目录

%% 默认参数
if ~isfield(io_cfg, 'data_root')
    error('io_cfg.data_root 未设置');
end

if ~isfield(io_cfg, 'prog_root')
    io_cfg.prog_root = pwd;
end

%% 当前时间文件夹名
nowStr = datestr(now, 'mmdd_HHMM');

%% 生成目录
data_dir = fullfile(io_cfg.data_root, nowStr);
prog_dir = fullfile(io_cfg.prog_root, nowStr);

if ~exist(data_dir, 'dir')
    mkdir(data_dir);
end

if ~exist(prog_dir, 'dir')
    mkdir(prog_dir);
end

%% 输出结构体
io = struct;
io.nowStr   = nowStr;
io.data_dir = data_dir;
io.prog_dir = prog_dir;

%% 打印信息
fprintf('Output folders created:\n');
fprintf('  data_dir = %s\n', data_dir);
fprintf('  prog_dir = %s\n', prog_dir);

end