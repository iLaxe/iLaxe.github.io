function s = run_scan_experiment(cfg, s)
% ================== run_scan_experiment.m ==================
% 通用导轨扫场 + 播放/采集流程
%
% 支持采集模式：
%   cfg.acq.mode = 'wav_record'   : 播放并用 audioDeviceReader 录 wav
%   cfg.acq.mode = 'bk_spectrum'  : 播放并用 BK Pulse 读取频谱
%
% 支持空跑：
%   cfg.run.dry_run = true        : 只移动滑轨，不播放、不录音、不读 BK
%
% 输入：
%   cfg : 实验配置结构体
%   s   : 已有 serialport 对象，可为空
%
% 输出：
%   s   : 初始化或复用后的 serialport 对象

%% 输入处理
if nargin < 2
    s = [];
end

%% 运行模式
if isfield(cfg, 'acq') && isfield(cfg.acq, 'mode')
    acq_mode = lower(string(cfg.acq.mode));
else
    acq_mode = "wav_record";
end

is_dry_run = isfield(cfg, 'run') && ...
             isfield(cfg.run, 'dry_run') && ...
             cfg.run.dry_run;

fprintf('Acquisition mode : %s\n', acq_mode);
fprintf('Dry run          : %d\n', is_dry_run);

%% 1) 初始化串口运动控制
s = init_motion_serial(s, cfg.motion);

%% 2) 读取音频
% dry_run 时跳过音频读取
if is_dry_run
    play_list   = {};
    audio_files = strings(0, 1);
    num_ch_play = 0;
    fprintf('Dry run: skip loading audio files.\n');
else
    [play_list, audio_files, num_ch_play] = ...
        load_audio_batch(cfg.audio, cfg.soundcard);
end

%% 3) 生成网格和扫描序列
scan = build_scan_grid_and_sequence(cfg.scan);

%% 4) 初始化实时进度图
rt = init_realtime_plot(scan);

%% 5) 创建保存目录并保存 meta
io = make_output_dirs(cfg.io);
save_scan_meta(cfg, scan, audio_files, io);

%% 5.5) 初始化扫描进度 txt，同步保存到 io.prog_dir
progress_txt_file = fullfile(io.prog_dir, 'scan_progress.txt');

scan_progress = struct();
scan_progress.start_time = datetime('now');
scan_progress.n_total    = scan.num_pts;

write_scan_progress_txt( ...
    progress_txt_file, ...
    scan_progress.start_time, ...
    0, ...
    scan_progress.n_total, ...
    NaN, ...
    NaN, ...
    NaT, ...
    NaN, ...
    NaN);

fprintf('Progress txt file: %s\n', progress_txt_file);

%% 6) BK 模式下初始化播放设备
deviceWriter = [];

try
    if ~is_dry_run && acq_mode == "bk_spectrum"

        if isfield(cfg.soundcard, 'min_play_ch')
            play_ch = max(cfg.soundcard.min_play_ch, num_ch_play);
        else
            play_ch = num_ch_play;
        end

        deviceWriter = init_bk_writer(cfg.soundcard, play_ch);
    end

    %% 7) 扫描前等待
    if isfield(cfg, 'timing') && isfield(cfg.timing, 'pause_before_scan_s')
        pause_s = cfg.timing.pause_before_scan_s;
    else
        pause_s = 0;
    end

    if pause_s > 0
        fprintf('Pause %.1f s before scan...\n', pause_s);
        pause(pause_s);
    end

    %% 扫描开始时间放在 pause 之后，更符合真实扫描耗时
    scan_progress.start_time = datetime('now');

    write_scan_progress_txt( ...
        progress_txt_file, ...
        scan_progress.start_time, ...
        0, ...
        scan_progress.n_total, ...
        0, ...
        NaN, ...
        NaT, ...
        NaN, ...
        NaN);

    %% 8) 执行扫描
    curr_pos = scan.curr_pos;

    for idx = 1:size(scan.scan_sequence, 1)

        goal_pos = scan.scan_sequence(idx, :);

        fprintf('\n================ Point %d / %d ================\n', ...
            idx, scan.num_pts);

        %% 路径规划
        path = astar(scan.map, curr_pos, goal_pos);

        if isempty(path)
            warning('无法到达点 (%d, %d)', goal_pos(1), goal_pos(2));

            update_scan_progress_txt( ...
                progress_txt_file, ...
                scan_progress.start_time, ...
                idx, ...
                scan.num_pts, ...
                NaN, ...
                NaN);

            continue;
        end

        %% 路径压缩
        waypoints = compress_path_to_waypoints(path);

        %% 逐段移动
        for w = 1:size(waypoints, 1)-1

            start_pos = waypoints(w, :);
            end_pos   = waypoints(w+1, :);

            move_robot_plane( ...
                start_pos, ...
                end_pos, ...
                cfg.scan.deltax, ...
                cfg.scan.deltay, ...
                cfg.scan.J, ...
                s, ...
                cfg.motion.move_timeout_s);
        end

        %% 到达测点
        curr_pos = path(end, :);

        xi = curr_pos(2);
        yi = curr_pos(1);

        x_phys = scan.x_points(xi);
        y_phys = scan.y_points(yi);

        fprintf('Arrived: xi=%d, yi=%d, x=%.4f m, y=%.4f m\n', ...
            xi, yi, x_phys, y_phys);

        %% 播放/采集
        if is_dry_run

            fprintf('Dry run: skip playback and acquisition at xi=%d, yi=%d\n', ...
                xi, yi);

        else

            switch acq_mode

                case "wav_record"

                    for ksig = 1:numel(play_list)

                        this_audio = play_list{ksig};

                        if isfield(cfg.soundcard, 'min_play_ch')
                            play_ch = max(cfg.soundcard.min_play_ch, num_ch_play);
                        else
                            play_ch = num_ch_play;
                        end

                        ok = playrec_one_sweep( ...
                            this_audio, ...
                            cfg.soundcard.fs, ...
                            cfg.soundcard.frmlen, ...
                            cfg.soundcard.driver, ...
                            cfg.soundcard.device, ...
                            play_ch, ...
                            io.data_dir, ...
                            xi, yi, x_phys, y_phys, ksig, ...
                            cfg.playrec);

                        if ~ok
                            warning('测点 xi=%d, yi=%d 的第 %d 段 sweep 多次尝试仍失败', ...
                                xi, yi, ksig);
                        end
                    end

                case "bk_spectrum"

                    if isfield(cfg, 'bk') && isfield(cfg.bk, 'pause_after_move_s')
                        pause(cfg.bk.pause_after_move_s);
                    end

                    measure_bk_segments( ...
                        xi, yi, ...
                        play_list, ...
                        cfg.soundcard.frmlen, ...
                        deviceWriter, ...
                        cfg.bk, ...
                        io.data_dir);

                otherwise

                    error('未知采集模式 cfg.acq.mode = %s', acq_mode);
            end
        end

        %% 更新扫描进度 txt
        update_scan_progress_txt( ...
            progress_txt_file, ...
            scan_progress.start_time, ...
            idx, ...
            scan.num_pts, ...
            x_phys, ...
            y_phys);

        %% 更新实时图
        rt = update_realtime_plot(rt, yi, xi, io.prog_dir);
    end

    fprintf('\nAll scan points finished.\n');

    %% 扫描完成后再写一次最终状态
    t_now = datetime('now');
    elapsed_sec = seconds(t_now - scan_progress.start_time);

    write_scan_progress_txt( ...
        progress_txt_file, ...
        scan_progress.start_time, ...
        scan.num_pts, ...
        scan.num_pts, ...
        elapsed_sec, ...
        0, ...
        t_now, ...
        NaN, ...
        NaN);

catch ME

    %% 出错时把错误信息附加写入 txt
    try
        write_scan_progress_txt( ...
            progress_txt_file, ...
            scan_progress.start_time, ...
            -1, ...
            scan_progress.n_total, ...
            seconds(datetime('now') - scan_progress.start_time), ...
            NaN, ...
            NaT, ...
            NaN, ...
            NaN);

        fid = fopen(progress_txt_file, 'a');
        if fid >= 0
            cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
            fprintf(fid, '\nERROR\n');
            fprintf(fid, '==============================\n');
            fprintf(fid, 'Error time          : %s\n', datestr(datetime('now'), 'yyyy-mm-dd HH:MM:SS'));
            fprintf(fid, 'Error identifier    : %s\n', ME.identifier);
            fprintf(fid, 'Error message       : %s\n', ME.message);

            if ~isempty(ME.stack)
                fprintf(fid, '\nStack:\n');
                for k = 1:numel(ME.stack)
                    fprintf(fid, '  %s, line %d\n', ME.stack(k).name, ME.stack(k).line);
                end
            end
        end
    catch
    end

    %% 出错时释放 BK/audioDeviceWriter
    if ~isempty(deviceWriter)
        try
            release(deviceWriter);
        catch
        end
    end

    rethrow(ME);
end

%% 正常结束时释放 BK/audioDeviceWriter
if ~isempty(deviceWriter)
    try
        release(deviceWriter);
    catch
    end
end

end