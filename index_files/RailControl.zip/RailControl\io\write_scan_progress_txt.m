function write_scan_progress_txt(filename, start_time, n_done, n_total, ...
    elapsed_sec, remaining_sec, finish_time_est, x_phys, y_phys)
% ================== write_scan_progress_txt.m ==================
% 将当前扫描进度写入 txt 文件。
% 每次覆盖写入，方便同步目录实时查看。
%
% 输入：
%   filename        : txt 文件完整路径
%   start_time      : 扫描开始时间，datetime 类型
%   n_done          : 已完成点数
%   n_total         : 总点数
%   elapsed_sec     : 已用时间，单位 s
%   remaining_sec   : 预计剩余时间，单位 s
%   finish_time_est : 预计完成时间，datetime 类型
%   x_phys          : 当前测点 x 坐标
%   y_phys          : 当前测点 y 坐标

fid = fopen(filename, 'w');

if fid < 0
    warning('Cannot write progress txt file: %s', filename);
    return;
end

cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

t_now = datetime('now');

fprintf(fid, 'Scan progress\n');
fprintf(fid, '==============================\n');
fprintf(fid, 'Start time          : %s\n', datestr(start_time, 'yyyy-mm-dd HH:MM:SS'));
fprintf(fid, 'Current time        : %s\n', datestr(t_now, 'yyyy-mm-dd HH:MM:SS'));

if n_done < 0
    fprintf(fid, 'Status              : ERROR\n');
    fprintf(fid, 'Finished points     : unknown / %d\n', n_total);
else
    fprintf(fid, 'Status              : RUNNING\n');
    fprintf(fid, 'Finished points     : %d / %d\n', n_done, n_total);
end

if n_total > 0 && n_done >= 0
    fprintf(fid, 'Progress            : %.2f %%\n', 100 * n_done / n_total);
else
    fprintf(fid, 'Progress            : NaN\n');
end

fprintf(fid, 'Elapsed time        : %s\n', format_seconds_or_blank(elapsed_sec));
fprintf(fid, 'Remaining time      : %s\n', format_seconds_or_blank(remaining_sec));
fprintf(fid, 'Estimated finish    : %s\n', datetime_to_string_or_blank(finish_time_est));

if ~isnan(x_phys) && ~isnan(y_phys)
    fprintf(fid, 'Current point x     : %.4f m\n', x_phys);
    fprintf(fid, 'Current point y     : %.4f m\n', y_phys);
else
    fprintf(fid, 'Current point x     : NaN\n');
    fprintf(fid, 'Current point y     : NaN\n');
end

end


function str = format_seconds_or_blank(t_sec)
% 把秒数格式化为 hh:mm:ss。
% 如果是 NaN，则返回 --:--:--。

if isnan(t_sec)
    str = '--:--:--';
    return;
end

t_sec = max(0, round(t_sec));

hh = floor(t_sec / 3600);
mm = floor(mod(t_sec, 3600) / 60);
ss = mod(t_sec, 60);

str = sprintf('%02d:%02d:%02d', hh, mm, ss);

end


function str = datetime_to_string_or_blank(t)
% datetime 转字符串。
% 如果是 NaT，则返回空白占位。

if isnat(t)
    str = '---- -- -- --:--:--';
else
    str = datestr(t, 'yyyy-mm-dd HH:MM:SS');
end

end