function ok = playrec_one_sweep(this_audio, fs, frmlen, driverName, deviceName, ...
    play_ch, save_dir, xi, yi, x_phys, y_phys, ksig, playrec_cfg)
% ================== playrec_one_sweep.m ==================
% 播放并录制一条 sweep，只保存 wav
%
% 依赖：
%   is_bad_signal.m

%% 默认参数
if ~isfield(playrec_cfg, 'max_attempts')
    playrec_cfg.max_attempts = 3;
end

if ~isfield(playrec_cfg, 'base_pause_s')
    playrec_cfg.base_pause_s = 1.5;
end

if ~isfield(playrec_cfg, 'qstep')
    playrec_cfg.qstep = 1e-7;
end

if ~isfield(playrec_cfg, 'max_levels')
    playrec_cfg.max_levels = 10;
end

if ~isfield(playrec_cfg, 'min_len')
    playrec_cfg.min_len = 1000;
end

if ~isfield(playrec_cfg, 'silent_p2p')
    playrec_cfg.silent_p2p = 1e-7;
end

%% 基本信息
Nsamp  = size(this_audio, 1);
numfrm = ceil(Nsamp / frmlen);

ok = false;

if ~exist(save_dir, 'dir')
    mkdir(save_dir);
end

%% 多次尝试
for attempt = 1:playrec_cfg.max_attempts

    fprintf('  sweep %d attempt %d ...\n', ksig, attempt);

    deviceReader = [];
    deviceWriter = [];

    try
        %% 播放设备
        deviceWriter = audioDeviceWriter( ...
            'Driver',     driverName, ...
            'Device',     deviceName, ...
            'SampleRate', fs);

        setup(deviceWriter, zeros(frmlen, play_ch));

        %% 录音设备：默认 2 通道
        deviceReader = audioDeviceReader( ...
            'Driver',          driverName, ...
            'Device',          deviceName, ...
            'SampleRate',      fs, ...
            'SamplesPerFrame', frmlen, ...
            'NumChannels',     2);

        setup(deviceReader);

        pause(playrec_cfg.base_pause_s);

        %% 播放 + 录音
        rec_buf = zeros(numfrm * frmlen, 2, 'double');

        for f = 1:numfrm

            idx_start = (f-1) * frmlen + 1;
            idx_end   = min(f * frmlen, Nsamp);

            y1 = this_audio(idx_start:idx_end, :);

            % 不足一帧补零
            if size(y1, 1) < frmlen
                y1(end+1:frmlen, :) = 0;
            end

            % 播放通道补零或截断
            if size(y1, 2) < play_ch
                y1(:, end+1:play_ch) = 0;
            elseif size(y1, 2) > play_ch
                y1 = y1(:, 1:play_ch);
            end

            deviceWriter(y1);

            r = deviceReader();

            if isempty(r)
                r = zeros(frmlen, 2);
            end

            valid_len = idx_end - idx_start + 1;
            rec_buf(idx_start:idx_end, 1:2) = r(1:valid_len, 1:2);
        end

        %% 释放设备
        release(deviceReader);
        release(deviceWriter);

        %% 截取有效长度
        rec_buf_trim = rec_buf(1:Nsamp, :);

        %% 检查录音质量
        [is_bad, stats] = is_bad_signal( ...
            rec_buf_trim(:, 1), ...
            playrec_cfg.qstep, ...
            playrec_cfg.max_levels, ...
            playrec_cfg.min_len, ...
            playrec_cfg.silent_p2p);

        if ~is_bad

            %% 只保存 wav
            base = sprintf('xi%d_yi%d_sig%d', xi, yi, ksig);
            wav_name = fullfile(save_dir, [base '_rec.wav']);

            audiowrite(wav_name, rec_buf_trim, fs, 'BitsPerSample', 24);

            fprintf('  -> OK 保存到 %s (N=%d, p2p=%.4g, n_levels=%d)\n', ...
                wav_name, stats.N, stats.p2p, stats.n_levels);

            ok = true;
            break;

        else

            fprintf('  -> 录到了但疑似坏文件 (N=%d, p2p=%.4g, n_levels=%d)，等 %.1fs 重试\n', ...
                stats.N, stats.p2p, stats.n_levels, playrec_cfg.base_pause_s);

            pause(playrec_cfg.base_pause_s);
        end

    catch ME

        warning('  -> 声卡出错：%s', ME.message);

        try
            if ~isempty(deviceReader)
                release(deviceReader);
            end
        catch
        end

        try
            if ~isempty(deviceWriter)
                release(deviceWriter);
            end
        catch
        end

        pause(playrec_cfg.base_pause_s);
    end
end

if ~ok
    fprintf('  !! sweep %d 尝试 %d 次仍失败\n', ...
        ksig, playrec_cfg.max_attempts);
end

end