function s = init_motion_serial(s, motion_cfg)
% ================== init_motion_serial.m ==================
% 初始化或复用串口对象，并设置速度、加速度
%
% 输入：
%   s          : 已有 serialport 对象；如果没有则传 []
%   motion_cfg : 运动控制配置
%
% 必需字段：
%   motion_cfg.com_port
%   motion_cfg.baudrate
%   motion_cfg.timeout_s
%   motion_cfg.max_speed_mm
%   motion_cfg.accel_mmps2
%
% 输出：
%   s : serialport 对象

%% 默认参数
if ~isfield(motion_cfg, 'com_port')
    error('motion_cfg.com_port 未设置');
end

if ~isfield(motion_cfg, 'baudrate')
    motion_cfg.baudrate = 9600;
end

if ~isfield(motion_cfg, 'timeout_s')
    motion_cfg.timeout_s = 10;
end

if ~isfield(motion_cfg, 'max_speed_mm')
    motion_cfg.max_speed_mm = 100;
end

if ~isfield(motion_cfg, 'accel_mmps2')
    motion_cfg.accel_mmps2 = 100;
end

com_port  = motion_cfg.com_port;
baudrate  = motion_cfg.baudrate;
timeout_s = motion_cfg.timeout_s;

%% 初始化或复用串口
need_new = true;

if nargin >= 1 && ~isempty(s)
    try
        if isvalid(s)
            need_new = false;
        end
    catch
        need_new = true;
    end
end

if need_new
    s = serialport(com_port, baudrate, "Timeout", timeout_s);
    configureTerminator(s, "LF");
    flush(s);
    pause(2);

    drain_serial(s);

    disp("Serial connected: " + com_port);
else
    s.Timeout = timeout_s;
    configureTerminator(s, "LF");
    flush(s);
    drain_serial(s);

    disp("Reuse existing serial: " + com_port);
end

%% 设置速度和加速度
serial_wait_ack(s, sprintf('v%d', round(motion_cfg.max_speed_mm)), ...
    "OK", timeout_s);

serial_wait_ack(s, sprintf('a%d', round(motion_cfg.accel_mmps2)), ...
    "OK", timeout_s);

fprintf('速度=%d mm/s，加速度=%d mm/s^2\n', ...
    round(motion_cfg.max_speed_mm), round(motion_cfg.accel_mmps2));

end