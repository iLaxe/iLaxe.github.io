# RailControl

RailControl is a MATLAB toolkit for rail-based acoustic scanning experiments. It combines serial motion control, scan-path generation, audio playback/recording, B&K spectrum acquisition, progress logging, and real-time visualization.

The main entry point is:

```matlab
cfg = example_config();
s = [];
s = run_scan_experiment(cfg, s);
```

Before running an experiment, copy `config/example_config.m` to a new configuration file and edit the serial port, sound card, scan geometry, audio folder, and output paths.

## Directory Layout

- `config/`: example experiment configuration.
- `run/`: top-level scan workflow.
- `motion/`: serial communication and rail movement.
- `scanpath/`: scan-grid construction, scan sequence generation, and A* path planning.
- `audio/`: audio loading, playback, recording, and signal-quality checks.
- `bk/`: B&K Pulse spectrum acquisition helpers.
- `io/`: output-folder creation, metadata saving, and scan-progress logging.
- `visualize/`: scan preview and real-time progress plotting.
- `utils/`: small path-processing utilities.

## Configuration Interface

`cfg = example_config()`

Returns a template configuration struct. Important fields include:

- `cfg.soundcard.fs`: audio sampling rate.
- `cfg.soundcard.frmlen`: audio frame length.
- `cfg.soundcard.driver`: audio driver name, for example `ASIO`.
- `cfg.soundcard.device`: playback/recording device name.
- `cfg.soundcard.min_play_ch`: minimum number of playback channels.
- `cfg.audio.folder`: folder containing input audio files.
- `cfg.audio.sig_duration`: nominal signal duration.
- `cfg.audio.gain_dB`: playback gain in dB.
- `cfg.scan.ax`, `cfg.scan.ay`: physical scan area size.
- `cfg.scan.deltax`, `cfg.scan.deltay`: spatial grid resolution.
- `cfg.scan.mode`: scan mode, such as `snake`, `circle`, `circle_densemid`, `circle_2step`, or `custom_points`.
- `cfg.scan.forbidden_zones`: forbidden rectangular regions in `[xmin xmax ymin ymax]` format.
- `cfg.scan.J`: mapping from grid-plane displacement to motor displacement.
- `cfg.motion.com_port`: serial COM port.
- `cfg.motion.baudrate`: serial baud rate.
- `cfg.motion.move_timeout_s`: timeout for each motion command.
- `cfg.acq.mode`: acquisition mode, either `wav_record` or `bk_spectrum`.
- `cfg.run.dry_run`: when true, moves the rail without playback or acquisition.
- `cfg.io.data_root`: root folder for recorded data.
- `cfg.io.prog_root`: root folder for progress files and metadata.

## Main Workflow

`s = run_scan_experiment(cfg, s)`

Runs one scan experiment.

Inputs:

- `cfg`: configuration struct.
- `s`: existing `serialport` object. Pass `[]` to initialize a new connection.

Output:

- `s`: initialized or reused serial connection.

Workflow:

1. Initialize rail serial control.
2. Load audio signals unless `cfg.run.dry_run` is true.
3. Build scan grid and scan sequence.
4. Initialize real-time progress plot.
5. Create output directories and save metadata.
6. Move through scan points using A* path planning.
7. At each point, either record WAV data or acquire B&K spectra.
8. Update progress text and visualization.

## Motion Interfaces

`s = init_motion_serial(s, motion_cfg)`

Initializes or reuses a MATLAB `serialport` object.

Key `motion_cfg` fields:

- `com_port`
- `baudrate`
- `timeout_s`
- `max_speed_mm`
- `accel_mmps2`

`d_motor = move_robot_plane(start_pos, end_pos, deltax, deltay, J, s, timeout_s)`

Moves the rail from one grid point to another.

Inputs:

- `start_pos`, `end_pos`: grid positions in `[iy, ix]` format.
- `deltax`, `deltay`: grid spacing in meters.
- `J`: plane-to-motor coordinate transform.
- `s`: serial connection.
- `timeout_s`: acknowledgement timeout.

Output:

- `d_motor`: commanded motor displacement.

`serial_wait_ack(s, cmd, expected, timeout_s)`

Sends a serial command and waits until the expected acknowledgement string is received.

`drain_serial(s)`

Clears pending serial input before issuing new commands.

## Scan-Path Interfaces

`scan = build_scan_grid_and_sequence(scan_cfg)`

Builds the scan grid, valid-region map, initial point, scan sequence, and physical scan coordinates.

Output fields include:

- `scan.x_points`, `scan.y_points`
- `scan.map`
- `scan.curr_pos`
- `scan.scan_sequence`
- `scan.scan_xy`
- `scan.num_pts`

`scan_sequence = generate_scan_sequence(mode, x_points, y_points, map, varargin)`

Generates scan points in `[iy, ix]` format.

Supported modes:

- `snake`
- `circle`
- `circle_densemid`
- `circle_2step`
- `custom_points`

`path = astar(map, start_pos, goal_pos)`

Finds a grid path from `start_pos` to `goal_pos` while avoiding forbidden cells.

`waypoints = compress_path_to_waypoints(path)`

Compresses a dense grid path into direction-change waypoints to reduce motion commands.

`scan_sequence = map_curve_to_grid(x_curve, y_curve, x_points, y_points, map, max_dist)`

Maps a continuous curve to the nearest valid scan-grid points.

`scan_sequence = custom_points_to_grid(xy_points, x_points, y_points, map, max_dist)`

Maps user-defined physical scan points to the nearest valid grid points.

`scan_sequence = gen_circle_2step(...)`

Generates a two-step circular scan with separate angular resolutions for the middle and side regions.

`path = reconstruct_path(came_from, current)`

Reconstructs an A* path from the predecessor table.

`h = heuristic(pos, goal)`

Computes the A* heuristic distance.

## Audio Interfaces

`[play_list, audio_files, num_ch_play] = load_audio_batch(audio_cfg, soundcard_cfg)`

Loads input audio files, applies gain/truncation settings, and prepares playback buffers.

`ok = playrec_one_sweep(this_audio, fs, frmlen, driverName, deviceName, play_ch, save_dir, xi, yi, x_phys, y_phys, ksig, playrec_cfg)`

Plays one sweep, records the response, checks signal quality, and saves a WAV file.

Key `playrec_cfg` fields:

- `max_attempts`
- `base_pause_s`
- `qstep`
- `max_levels`
- `min_len`
- `silent_p2p`

`[is_bad, stats] = is_bad_signal(sig, qstep, max_levels, min_len, silent_p2p)`

Checks whether a recorded signal is clipped, too short, silent, or otherwise invalid.

## B&K Interfaces

`deviceWriter = init_bk_writer(soundcard_cfg, play_ch)`

Creates an audio writer used when the acquisition mode is `bk_spectrum`.

`measure_bk_segments(xi, yi, play_list, frmlen, deviceWriter, bk_cfg, data_dir)`

Plays multiple signal segments at one scan point and saves B&K spectrum data.

Key `bk_cfg` fields:

- `funcs`
- `pause_between_segments_s`
- `pause_after_move_s`
- `output_prefix`

`[data1, data2, axis] = BKmeasure1(xin, numfrm, frmlen, deviceWriter, which_funcs)`

Low-level helper for reading spectrum data from B&K Pulse.

## I/O Interfaces

`io = make_output_dirs(io_cfg)`

Creates data and progress output folders.

`save_scan_meta(cfg, scan, audio_files, io)`

Saves configuration, scan grid, scan sequence, and audio-file metadata.

`write_scan_progress_txt(filename, start_time, n_done, n_total, elapsed_sec, remaining_sec, finish_time_est, x_phys, y_phys)`

Writes a full scan-progress text file.

`update_scan_progress_txt(filename, start_time, n_done, n_total, x_phys, y_phys)`

Updates scan-progress status during the experiment.

## Visualization Interfaces

`preview_scan_points(cfg)`

Previews the scan points before running the experiment.

`rt = init_realtime_plot(scan)`

Initializes a real-time scan-progress figure.

`rt = update_realtime_plot(rt, yi, xi, prog_dir)`

Updates the real-time scan-progress plot and optionally writes progress images to `prog_dir`.

## Notes

- The project assumes MATLAB with audio I/O support and access to the required rail controller serial interface.
- B&K acquisition requires the local B&K Pulse environment used by the `bk/` functions.
- Use `cfg.run.dry_run = true` to test motion and scan sequencing without playback or acquisition.
