function [data1, data2, axis] = BKmeasure1(xin, numfrm, frmlen, deviceWriter, which_funcs)
% ================== BKmeasure1.m ==================
% 播放一段音频，并从 BK Pulse/LabShop 读取指定 Function 的频谱数据
%
% 输入：
%   xin          : 要播放的音频，Nsamp x Nch
%   numfrm       : 播放帧数
%   frmlen       : 每帧长度
%   deviceWriter : audioDeviceWriter 对象
%   which_funcs  : BK Function 编号，例如 [1] 或 [1 2]
%
% 输出：
%   data1        : Function 1 数据，如果未读取则为空
%   data2        : Function 2 数据，如果未读取则为空
%   axis         : 频率轴

%% 默认参数
if nargin < 5 || isempty(which_funcs)
    which_funcs = [1 2];
end

if isscalar(which_funcs)
    which_funcs = which_funcs(:).';
end

data1 = [];
data2 = [];
axis  = [];

%% 连接 BK Pulse
try
    pulse = actxserver('Pulse.Labshop.Application');
    set(pulse, 'visible', 1);
catch ME
    warning('无法连接 BK Pulse/LabShop：%s', ME.message);
    return;
end

%% 开始测量并播放音频
try
    invoke(pulse, 'Start');

    for i = 1:floor(numfrm)

        idx_start = (i-1) * frmlen + 1;
        idx_end   = min(i * frmlen, size(xin, 1));

        y1 = real(xin(idx_start:idx_end, :));

        if size(y1, 1) < frmlen
            y1(end+1:frmlen, :) = 0;
        end

        deviceWriter(y1);
    end

    pause(0.1);

    invoke(pulse, 'Stop');

    pause(0.1);

catch ME
    warning('BK 播放/测量过程出错：%s', ME.message);

    try
        invoke(pulse, 'Stop');
    catch
    end

    return;
end

%% 读取 BK Function 数据
try
    func_org    = pulse.Project.FunctionOrganiser;
    func_groups = get(func_org, 'FunctionGroups');

    func_group = get(func_groups, 'Item', int32(1));
    funcs      = get(func_group, 'Functions');

    if numel(which_funcs) >= 1
        idx1  = int32(which_funcs(1));
        func1 = get(funcs, 'Item', idx1);
        data1 = func1.GetAllValues(1);
    end

    if numel(which_funcs) >= 2
        idx2  = int32(which_funcs(2));
        func2 = get(funcs, 'Item', idx2);
        data2 = func2.GetAllValues(1);
    end

catch ME
    warning('读取 BK Function 数据出错：%s', ME.message);
    return;
end

%% 读取频率轴
try
    mo    = pulse.Project.MeasurementOrganiser;
    Temps = get(mo, 'Templates', 'Working');
    temp  = get(Temps, 'Setup');
    FFT   = get(temp, 'Instruments', 'FFT Analyzer');

    lines = get(FFT, 'lines');
    span  = get(FFT, 'Span');

    axis = linspace(0, span, lines + 1);

catch ME
    warning('获取 BK 频率轴出错：%s', ME.message);
    axis = [];
end

end