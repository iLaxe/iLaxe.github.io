function drain_serial(s)
% ================== drain_serial.m ==================
% 清空串口缓存中的残留回包

if isempty(s) || ~isvalid(s)
    return;
end

t0 = tic;

while toc(t0) < 0.2
    if s.NumBytesAvailable > 0
        try
            readline(s); %#ok<NASGU>
        catch
            break;
        end
    else
        pause(0.01);
    end
end

end