function scan = build_scan_grid_and_sequence(scan_cfg)
% ================== build_scan_grid_and_sequence.m ==================
% 根据 cfg.scan 生成：
%   1) x/y 网格
%   2) 可扫描地图 map
%   3) 起始点
%   4) 扫描点序列 scan_sequence
%   5) 扫描点物理坐标 scan_xy

%% 基本参数检查
required_fields = {'ax', 'ay', 'deltax', 'deltay', 'mode'};

for i = 1:numel(required_fields)
    if ~isfield(scan_cfg, required_fields{i})
        error('scan_cfg.%s 未设置', required_fields{i});
    end
end

if ~isfield(scan_cfg, 'forbidden_zones')
    scan_cfg.forbidden_zones = [];
end

%% 网格
x_points = -scan_cfg.ax/2 : scan_cfg.deltax : scan_cfg.ax/2;
y_points = 0              : scan_cfg.deltay : scan_cfg.ay;

nx = numel(x_points);
ny = numel(y_points);

%% 可扫描区域 map
map = ones(ny, nx);

for iy = 1:ny
    for ix = 1:nx

        xg = x_points(ix);
        yg = y_points(iy);

        for k = 1:size(scan_cfg.forbidden_zones, 1)

            zone = scan_cfg.forbidden_zones(k, :);

            if xg >= zone(1) && xg <= zone(2) && ...
               yg >= zone(3) && yg <= zone(4)
                map(iy, ix) = 0;
            end
        end
    end
end

%% 起点，默认取最接近 (0, 0) 的网格点
[~, ix0] = min(abs(x_points - 0));
[~, iy0] = min(abs(y_points - 0));

curr_pos = [iy0, ix0];

%% 生成扫描序列
switch lower(scan_cfg.mode)

    case 'snake'

        scan_sequence = generate_scan_sequence( ...
            'snake', x_points, y_points, map);

    case 'circle'

        scan_sequence = generate_scan_sequence( ...
            'circle', x_points, y_points, map, ...
            scan_cfg.circle.center, ...
            scan_cfg.circle.radius, ...
            scan_cfg.circle.N, ...
            scan_cfg.circle.tol);

    case 'circle_densemid'

        scan_sequence = generate_scan_sequence( ...
            'circle_densemid', x_points, y_points, map, ...
            scan_cfg.circle.center, ...
            scan_cfg.circle.radius, ...
            scan_cfg.circle.N, ...
            scan_cfg.circle.tol);

    case 'circle_2step'

        scan_sequence = generate_scan_sequence( ...
            'circle_2step', x_points, y_points, map, ...
            scan_cfg.circle.center, ...
            scan_cfg.circle.radius, ...
            scan_cfg.circle_2step.theta_mid_deg, ...
            scan_cfg.circle_2step.dtheta_mid_deg, ...
            scan_cfg.circle_2step.dtheta_side_deg, ...
            scan_cfg.circle.tol);

    case 'custom_points'
        scan_sequence = generate_scan_sequence( ...
            'custom_points', x_points, y_points, map, ...
            scan_cfg.custom.xy, ...
                scan_cfg.custom.tol);

    otherwise
        error('未知 scan_cfg.mode: %s', scan_cfg.mode);
end

%% 扫描点对应的物理坐标
num_pts = size(scan_sequence, 1);
scan_xy = zeros(num_pts, 2);

for ii = 1:num_pts

    iy = scan_sequence(ii, 1);
    ix = scan_sequence(ii, 2);

    scan_xy(ii, :) = [x_points(ix), y_points(iy)];
end

%% 输出结构体
scan = struct;

scan.x_points      = x_points;
scan.y_points      = y_points;
scan.nx            = nx;
scan.ny            = ny;
scan.map           = map;

scan.ix0           = ix0;
scan.iy0           = iy0;
scan.x0            = x_points(ix0);
scan.y0            = y_points(iy0);
scan.curr_pos      = curr_pos;

scan.scan_sequence = scan_sequence;
scan.scan_xy       = scan_xy;
scan.num_pts       = num_pts;

fprintf('Scan mode = %s\n', scan_cfg.mode);
fprintf('Grid size = %d x %d\n', nx, ny);
fprintf('Total scan points = %d\n', num_pts);

end