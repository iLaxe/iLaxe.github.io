function path = reconstruct_path(came_from, current)
% ================== reconstruct_path.m ==================
% 从 A* 的 came_from 数组中反推完整路径
%
% 输入：
%   came_from : ny x nx x 2 数组，记录每个点的前驱点
%   current   : 当前终点 [iy, ix]
%
% 输出：
%   path      : 从起点到终点的路径，每行为 [iy, ix]

path = current;

while any(came_from(current(1), current(2), :))
    current = squeeze(came_from(current(1), current(2), :))';
    path = [current; path]; %#ok<AGROW>
end

end