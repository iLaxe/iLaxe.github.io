function cfg = example_config()
% ================== example_config.m ==================
% RailControl 通用配置示例
% 具体实验建议复制本文件并改名，例如：
%   make_config_phaseonly_scan.m
%
% 注意：
%   本文件只作为模板，不建议直接用于正式实验。

%% 声卡参数
cfg.soundcard.fs      = 192000;
cfg.soundcard.frmlen  = 4096;
cfg.soundcard.driver  = 'ASIO';
cfg.soundcard.device  = 'Your ASIO Device Name';
cfg.soundcard.min_play_ch = 24;

%% 输入音频
cfg.audio.folder       = "D:\YourAudioFolder";
cfg.audio.sig_duration = 3;
cfg.audio.gain_dB      = -16;
cfg.audio.do_truncate  = false;

%% 扫描网格
cfg.scan.ax     = 2.00;
cfg.scan.ay     = 2.00;
cfg.scan.deltax = 0.01;
cfg.scan.deltay = 0.01;

% 支持：
%   'snake'
%   'circle'
%   'circle_densemid'
%   'circle_2step'
cfg.scan.mode = 'circle';

% 禁区格式：[xmin xmax ymin ymax]
cfg.scan.forbidden_zones = [];

%% 圆形轨迹参数
cfg.scan.circle.center = [0, -0.06];
cfg.scan.circle.radius = 1.00;
cfg.scan.circle.N      = 70;
cfg.scan.circle.tol    = cfg.scan.deltax / 2;

%% circle_2step 参数
cfg.scan.circle_2step.theta_mid_deg   = 60;
cfg.scan.circle_2step.dtheta_mid_deg  = 3.0;
cfg.scan.circle_2step.dtheta_side_deg = 3.0;

%% 机械坐标 -> 平面坐标映射
% 当前示例：
%   plane X = motor X
%   plane Y = - motor Y
cfg.scan.J = [1 0 0;
              0 -1 0];

%% 串口运动控制
cfg.motion.com_port  = "COM13";
cfg.motion.baudrate  = 9600;
cfg.motion.timeout_s = 10;

cfg.motion.max_speed_mm = 100;
cfg.motion.accel_mmps2  = 100;

% 单条运动命令等待 DONE 的超时时间
cfg.motion.move_timeout_s = 60;

%% 播放录音参数
cfg.playrec.max_attempts = 10;
cfg.playrec.base_pause_s = 3;

% 坏录音检测参数
cfg.playrec.qstep       = 1e-7;
cfg.playrec.max_levels  = 10;
cfg.playrec.min_len     = 1000;
cfg.playrec.silent_p2p  = 1e-7;

%% 保存路径
cfg.io.data_root = "D:\Data\RailControl";
cfg.io.prog_root = pwd;

%% 时间控制
cfg.timing.pause_before_scan_s = 35;

end