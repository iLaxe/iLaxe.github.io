function scan_sequence = gen_circle_2step(x_points, y_points, map, ...
    center, radius, theta_mid_deg, dtheta_mid_deg, dtheta_side_deg, tol)
% ================== gen_circle_2step.m ==================
% 生成 circle_2step 圆弧扫描轨迹
%
% 角度定义：
%   0 deg   : 右端
%   90 deg  : 轴线方向
%   180 deg : 左端
%
% 当前只保留轴线 ±60 deg，即 [30, 150] deg

x0 = center(1);
y0 = center(2);

th_left_deg  = 180;
th_axis_deg  = 90;
th_midL_deg  = th_axis_deg + theta_mid_deg;
th_midR_deg  = th_axis_deg - theta_mid_deg;
th_right_deg = 0;

thetaL = th_left_deg : -dtheta_side_deg : th_midL_deg;
thetaM = th_midL_deg : -dtheta_mid_deg  : th_midR_deg;
thetaR = th_midR_deg : -dtheta_side_deg : th_right_deg;

theta_deg = [thetaL, thetaM(2:end), thetaR(2:end)];

% 只保留轴线 ±60°
keep_min = 30;
keep_max = 150;

mask = theta_deg >= keep_min & theta_deg <= keep_max;
theta_deg = theta_deg(mask);

theta_rad = deg2rad(theta_deg);

x_curve = x0 + radius * cos(theta_rad);
y_curve = y0 + radius * sin(theta_rad);

scan_sequence = map_curve_to_grid( ...
    x_curve, y_curve, x_points, y_points, map, tol);

end