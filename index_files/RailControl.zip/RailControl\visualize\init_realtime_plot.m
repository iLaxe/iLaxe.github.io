function rt = init_realtime_plot(scan)
% ================== init_realtime_plot.m ==================
% 初始化实时扫场进度图
%
% 输入：
%   scan.x_points
%   scan.y_points
%   scan.nx
%   scan.ny
%
% 输出：
%   rt.field : 进度矩阵
%   rt.h_img : imagesc 图像句柄
%   rt.h_fig : figure 句柄
%   rt.h_ax  : axes 句柄

field = nan(scan.ny, scan.nx);

h_fig = figure;
h_ax  = axes(h_fig);

h_img = imagesc(h_ax, scan.x_points, scan.y_points, field);

axis(h_ax, 'equal');
axis(h_ax, 'tight');
set(h_ax, 'YDir', 'normal');

colormap(h_ax, [1 1 1; 0 0 0]);
caxis(h_ax, [0, 1]);

title(h_ax, '实时扫场示意图');
xlabel(h_ax, 'X (m)');
ylabel(h_ax, 'Y (m)');

rt = struct;
rt.field = field;
rt.h_fig = h_fig;
rt.h_ax  = h_ax;
rt.h_img = h_img;

end