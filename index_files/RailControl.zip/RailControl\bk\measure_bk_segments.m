function measure_bk_segments(xi, yi, play_list, frmlen, deviceWriter, bk_cfg, data_dir)
% ================== measure_bk_segments.m ==================
% 在一个测点依次播放多个 segment，并用 BK Pulse 读取频谱
%
% 输入：
%   xi, yi       : 当前网格索引
%   play_list    : cell，每个元素是一段要播放的音频
%   frmlen       : 声卡帧长
%   deviceWriter : audioDeviceWriter 对象
%   bk_cfg       : BK 配置
%   data_dir     : 数据保存根目录
%
% 输出：
%   data_dir/sig1/xi*_yi*_spectrum1.mat
%   data_dir/sig2/xi*_yi*_spectrum1.mat
%   ...

%% 默认参数
if ~isfield(bk_cfg, 'funcs')
    bk_cfg.funcs = [1];
end

if ~isfield(bk_cfg, 'pause_between_segments_s')
    bk_cfg.pause_between_segments_s = 2;
end

if ~isfield(bk_cfg, 'output_prefix')
    bk_cfg.output_prefix = "sig";
end

if ~exist(data_dir, 'dir')
    mkdir(data_dir);
end

%% 逐段播放并读取 BK
for k = 1:numel(play_list)

    audio_data = play_list{k};

    if isempty(audio_data)
        warning('BK segment %d 为空，跳过', k);
        continue;
    end

    numfrm = floor(size(audio_data, 1) / frmlen);

    if numfrm <= 0
        warning('BK segment %d 长度不足一帧，跳过', k);
        continue;
    end

    folder_name = fullfile(data_dir, sprintf('%s%d', bk_cfg.output_prefix, k));

    if ~exist(folder_name, 'dir')
        mkdir(folder_name);
    end

    fprintf('  BK segment %d / %d ...\n', k, numel(play_list));

    [data1, data2, axis] = BKmeasure1( ...
        audio_data, ...
        numfrm, ...
        frmlen, ...
        deviceWriter, ...
        bk_cfg.funcs);

    %% 保存 Function 1
    if ~isempty(data1)
        spl_data1 = 20 * log10(sqrt(data1) ./ (2e-5));

        save(fullfile(folder_name, sprintf('xi%d_yi%d_spectrum1.mat', xi, yi)), ...
            'spl_data1', 'axis');

        fprintf('    saved spectrum1: sig%d / xi%d_yi%d\n', k, xi, yi);
    else
        warning('BK segment %d: data1 为空', k);
    end

    %% 保存 Function 2
    if ~isempty(data2)
        spl_data2 = 20 * log10(sqrt(data2) ./ (2e-5));

        save(fullfile(folder_name, sprintf('xi%d_yi%d_spectrum2.mat', xi, yi)), ...
            'spl_data2', 'axis');

        fprintf('    saved spectrum2: sig%d / xi%d_yi%d\n', k, xi, yi);
    end

    %% 段间等待
    if k < numel(play_list)
        pause(bk_cfg.pause_between_segments_s);
    end
end

end