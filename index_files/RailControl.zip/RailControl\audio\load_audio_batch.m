function [play_list, audio_files, num_ch_play] = load_audio_batch(audio_cfg, soundcard_cfg)
% ================== load_audio_batch.m ==================
% 读取并处理一批 wav 音频
%
% 支持两种模式：
%
% 1) 文件夹模式：
%   audio_cfg.folder       : wav 文件夹
%   audio_cfg.sig_duration : 截断时长，单位 s
%   audio_cfg.gain_dB      : 播放增益，单位 dB
%   audio_cfg.do_truncate  : 是否截断
%
% 2) segments 模式：
%   audio_cfg.use_segments = true
%   audio_cfg.segments     : cell，每个元素为 struct
%       .file      : wav 文件路径
%       .gain_dB   : 当前段播放增益，单位 dB
%       .do_cut    : 是否按时间截取
%       .t_start   : 截取起始时间，单位 s
%       .t_dur     : 截取时长，单位 s
%
%   segments 模式下，每段可以有自己的 gain 和截取区间。
%
% 输入：
%   soundcard_cfg.fs       : 目标采样率
%
% 输出：
%   play_list    : cell，每个元素是一条处理后的音频
%   audio_files  : string 数组，原始 wav 文件路径
%   num_ch_play  : 第一条音频的通道数

%% 基本检查
if ~isfield(soundcard_cfg, 'fs')
    error('soundcard_cfg.fs 未设置');
end

fs = soundcard_cfg.fs;

if ~isfield(audio_cfg, 'use_segments')
    audio_cfg.use_segments = false;
end

if ~isfield(audio_cfg, 'do_truncate')
    audio_cfg.do_truncate = false;
end

if ~isfield(audio_cfg, 'sig_duration')
    audio_cfg.sig_duration = inf;
end

if ~isfield(audio_cfg, 'gain_dB')
    audio_cfg.gain_dB = 0;
end

%% ================== segments 模式 ==================
if audio_cfg.use_segments

    if ~isfield(audio_cfg, 'segments') || isempty(audio_cfg.segments)
        error('audio_cfg.use_segments=true，但 audio_cfg.segments 未设置或为空');
    end

    segments = audio_cfg.segments;
    num_seg  = numel(segments);

    play_list   = cell(num_seg, 1);
    audio_files = strings(num_seg, 1);

    for ii = 1:num_seg

        seg = segments{ii};

        if ~isfield(seg, 'file')
            error('audio_cfg.segments{%d}.file 未设置', ii);
        end

        fn = string(seg.file);

        if ~isfile(fn)
            error('音频文件不存在：%s', fn);
        end

        [xin, fsa] = audioread(fn);
        audio_files(ii) = fn;

        %% 当前 segment 的截取设置
        if ~isfield(seg, 'do_cut')
            seg.do_cut = false;
        end

        if seg.do_cut
            if ~isfield(seg, 't_start')
                seg.t_start = 0;
            end

            if ~isfield(seg, 't_dur')
                seg.t_dur = audio_cfg.sig_duration;
            end

            i1 = max(1, floor(seg.t_start * fsa) + 1);

            if isinf(seg.t_dur)
                i2 = size(xin, 1);
            else
                i2 = min(size(xin, 1), i1 + round(seg.t_dur * fsa) - 1);
            end

            if i1 > size(xin, 1)
                error('segment %d 的 t_start 超出音频长度：%s', ii, fn);
            end

            xin = xin(i1:i2, :);

        elseif audio_cfg.do_truncate
            max_len = round(audio_cfg.sig_duration * fsa);
            xin = xin(1:min(end, max_len), :);
        end

        %% 峰值归一化
        peakVal = max(abs(xin), [], 'all');

        if peakVal > 0
            xin = xin / peakVal;
        else
            warning('音频 %s 全为 0，跳过归一化。', fn);
        end

        %% 重采样到目标 fs
        if fsa ~= fs
            xin = resample(xin, fs, fsa);
        end

        %% 当前 segment 的 gain
        if isfield(seg, 'gain_dB')
            gain_dB = seg.gain_dB;
        else
            gain_dB = audio_cfg.gain_dB;
        end

        xin = xin * db2mag(gain_dB);

        play_list{ii} = xin;
    end

    num_ch_play = size(play_list{1}, 2);

    fprintf('Loaded %d audio segments.\n', numel(play_list));
    fprintf('Target fs = %d Hz\n', fs);
    fprintf('Playback channels in first segment = %d\n', num_ch_play);

    return;
end

%% ================== 文件夹模式 ==================
if ~isfield(audio_cfg, 'folder')
    error('audio_cfg.folder 未设置');
end

audio_folder = audio_cfg.folder;

%% 查找 wav 文件
files = dir(fullfile(audio_folder, '*.wav'));

if isempty(files)
    error('音频文件夹中没有找到 wav 文件：%s', audio_folder);
end

[~, idx] = sort({files.name});
files = files(idx);

audio_files = strings(numel(files), 1);

for i = 1:numel(files)
    audio_files(i) = fullfile(files(i).folder, files(i).name);
end

%% 读取并处理音频
play_list = cell(numel(audio_files), 1);

for ii = 1:numel(audio_files)

    [xin, fsa] = audioread(audio_files(ii));

    %% 可选截断
    if audio_cfg.do_truncate
        max_len = round(audio_cfg.sig_duration * fsa);
        xin = xin(1:min(end, max_len), :);
    end

    %% 峰值归一化到 1
    peakVal = max(abs(xin), [], 'all');

    if peakVal > 0
        xin = xin / peakVal;
    else
        warning('音频 %s 全为 0，跳过归一化。', audio_files(ii));
    end

    %% 重采样到目标 fs
    if fsa ~= fs
        xin = resample(xin, fs, fsa);
    end

    %% 播放增益
    xin = xin * db2mag(audio_cfg.gain_dB);

    play_list{ii} = xin;
end

%% 通道数
num_ch_play = size(play_list{1}, 2);

fprintf('Loaded %d wav files from:\n%s\n', numel(audio_files), audio_folder);
fprintf('Target fs = %d Hz\n', fs);
fprintf('Playback gain = %.2f dB\n', audio_cfg.gain_dB);
fprintf('Playback channels in first file = %d\n', num_ch_play);

end