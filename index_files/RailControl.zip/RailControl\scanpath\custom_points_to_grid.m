function scan_sequence = custom_points_to_grid(xy_points, x_points, y_points, map, max_dist)
% ================== custom_points_to_grid.m ==================
% 将自定义物理坐标 [x,y] 映射到最近网格点
%
% 输入：
%   xy_points : N x 2，自定义测量点坐标，单位 m，每行为 [x, y]
%   x_points  : 网格 x 坐标
%   y_points  : 网格 y 坐标
%   map       : 可扫描区域地图，1 可扫，0 禁区
%   max_dist  : 最大允许映射误差，单位 m
%
% 输出：
%   scan_sequence : N x 2，每行为 [iy, ix]

if isempty(xy_points)
    error('自定义测量点 xy_points 为空');
end

if size(xy_points, 2) ~= 2
    error('xy_points 必须是 N x 2，每行为 [x, y]');
end

scan_sequence = [];
used_idx = [];

for i = 1:size(xy_points, 1)

    x_real = xy_points(i, 1);
    y_real = xy_points(i, 2);

    [~, ix] = min(abs(x_points - x_real));
    [~, iy] = min(abs(y_points - y_real));

    x_grid = x_points(ix);
    y_grid = y_points(iy);

    dist = hypot(x_real - x_grid, y_real - y_grid);

    if dist > max_dist
        warning('自定义点 %d: (%.4f, %.4f) 距最近网格点 %.4g m，超过 tol=%.4g，跳过', ...
            i, x_real, y_real, dist, max_dist);
        continue;
    end

    if map(iy, ix) ~= 1
        warning('自定义点 %d: (%.4f, %.4f) 映射到禁区，跳过', ...
            i, x_real, y_real);
        continue;
    end

    key = iy * 10000 + ix;

    if ismember(key, used_idx)
        warning('自定义点 %d: (%.4f, %.4f) 与前面点映射到同一网格点，跳过重复点', ...
            i, x_real, y_real);
        continue;
    end

    scan_sequence = [scan_sequence; iy, ix]; %#ok<AGROW>
    used_idx = [used_idx, key]; %#ok<AGROW>
end

if isempty(scan_sequence)
    error('所有自定义测量点都无效，scan_sequence 为空');
end

end