function serial_wait_ack(s, cmd, expected, timeout_s)
% ================== serial_wait_ack.m ==================
% 发送串口命令并等待指定 ACK
%
% 输入：
%   s          : serialport 对象
%   cmd        : 要发送的命令，例如 'x10', 'v100'
%   expected   : 期望回包，例如 "OK", "DONE"
%   timeout_s  : 超时时间，单位 s

if nargin < 4 || isempty(timeout_s)
    timeout_s = 10;
end

if isempty(s) || ~isvalid(s)
    error('串口对象无效');
end

s.Timeout = timeout_s;

% 发送前清缓存，避免历史回包污染
drain_serial(s);

writeline(s, cmd);

t0 = tic;
last = "";
all_resp = strings(0, 1); %#ok<NASGU>

while toc(t0) < timeout_s

    if s.NumBytesAvailable > 0

        try
            resp = strtrim(readline(s));
        catch
            resp = "";
        end

        if strlength(resp) == 0
            continue;
        end

        resp = string(resp);
        last = resp;
        all_resp(end+1, 1) = resp; %#ok<AGROW>

        % 精确匹配
        if strcmpi(resp, expected)
            return;
        end

        % 明确错误
        if strcmpi(resp, "ERR")
            error('命令 %s 返回 ERR', cmd);
        end

        % 容忍 DONE 被污染
        if strcmpi(expected, "DONE")
            if contains(resp, "DONE", 'IgnoreCase', true) || ...
               contains(resp, "ONE",  'IgnoreCase', true) || ...
               contains(resp, "DON",  'IgnoreCase', true)

                warning('命令 %s 收到疑似污染 ACK: "%s"，按 DONE 处理', ...
                    cmd, resp);
                return;
            end
        end

    else
        pause(0.005);
    end
end

error('命令 %s 超时，期望 %s，最后收到: %s', cmd, expected, last);

end