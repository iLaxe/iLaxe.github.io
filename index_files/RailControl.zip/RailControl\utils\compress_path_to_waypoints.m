function waypoints = compress_path_to_waypoints(path)
% ================== compress_path_to_waypoints.m ==================
% 将逐格路径压缩为转折点路径
%
% 输入：
%   path      : A* 输出路径，每行为 [iy, ix]
%
% 输出：
%   waypoints : 压缩后的路径，只保留起点、终点和转折点

%% 空路径
if isempty(path)
    waypoints = [];
    return;
end

%% 单点路径
if size(path, 1) == 1
    waypoints = path;
    return;
end

%% 起点
waypoints = path(1, :);

%% 初始方向
prev_vec = path(2, :) - path(1, :);

%% 检测方向变化点
for p = 2:size(path, 1)-1

    curr_vec = path(p+1, :) - path(p, :);

    if ~isequal(curr_vec, prev_vec)
        waypoints = [waypoints; path(p, :)]; %#ok<AGROW>
        prev_vec = curr_vec;
    end
end

%% 终点
waypoints = [waypoints; path(end, :)];

end