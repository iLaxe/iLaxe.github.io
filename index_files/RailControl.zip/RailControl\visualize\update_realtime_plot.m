function rt = update_realtime_plot(rt, yi, xi, prog_dir)
% ================== update_realtime_plot.m ==================
% 更新实时扫场进度图，并保存 latest_field.png
%
% 输入：
%   rt       : init_realtime_plot 返回的结构体
%   yi, xi   : 当前完成测点的网格索引
%   prog_dir : 进度图保存目录
%
% 输出：
%   rt       : 更新后的结构体

%% 更新进度矩阵
rt.field(yi, xi) = 1;

%% 更新图像
set(rt.h_img, 'CData', rt.field);
drawnow limitrate;

%% 保存 latest_field.png
if nargin >= 4 && ~isempty(prog_dir)

    if ~exist(prog_dir, 'dir')
        mkdir(prog_dir);
    end

    frame = getframe(rt.h_ax);
    imwrite(frame.cdata, fullfile(prog_dir, 'latest_field.png'));
end

end