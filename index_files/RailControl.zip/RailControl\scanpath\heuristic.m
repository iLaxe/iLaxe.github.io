function h = heuristic(pos, goal)
% ================== heuristic.m ==================
% A* 路径规划的启发函数
% 使用曼哈顿距离，适合上下左右四邻域移动

h = abs(pos(1) - goal(1)) + abs(pos(2) - goal(2));

end