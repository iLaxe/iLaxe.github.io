function path = astar(map, start_pos, goal_pos)
% ================== astar.m ==================
% A* 路径规划
%
% 输入：
%   map       : ny x nx 地图，1 表示可走，0 表示禁区
%   start_pos : 起点 [iy, ix]
%   goal_pos  : 终点 [iy, ix]
%
% 输出：
%   path      : 从起点到终点的路径，每行为 [iy, ix]
%               如果不可达，返回 []

[ny, nx] = size(map);

open_set   = start_pos;
closed_set = false(ny, nx);

g_score = inf(ny, nx);
f_score = inf(ny, nx);

came_from = zeros(ny, nx, 2);

g_score(start_pos(1), start_pos(2)) = 0;
f_score(start_pos(1), start_pos(2)) = heuristic(start_pos, goal_pos);

neighbors = [-1 0;
              1 0;
              0 1;
              0 -1];

while ~isempty(open_set)

    scores = arrayfun(@(idx) ...
        f_score(open_set(idx, 1), open_set(idx, 2)), ...
        1:size(open_set, 1));

    [~, idx_min] = min(scores);
    current = open_set(idx_min, :);

    if isequal(current, goal_pos)
        path = reconstruct_path(came_from, current);
        return;
    end

    open_set(idx_min, :) = [];
    closed_set(current(1), current(2)) = true;

    for n = 1:size(neighbors, 1)

        neighbor = current + neighbors(n, :);

        if neighbor(1) < 1 || neighbor(1) > ny || ...
           neighbor(2) < 1 || neighbor(2) > nx
            continue;
        end

        if map(neighbor(1), neighbor(2)) == 0 || ...
           closed_set(neighbor(1), neighbor(2))
            continue;
        end

        tentative_g = g_score(current(1), current(2)) + 1;

        if tentative_g < g_score(neighbor(1), neighbor(2))

            came_from(neighbor(1), neighbor(2), :) = current;

            g_score(neighbor(1), neighbor(2)) = tentative_g;

            f_score(neighbor(1), neighbor(2)) = ...
                tentative_g + heuristic(neighbor, goal_pos);

            if ~ismember(neighbor, open_set, 'rows')
                open_set = [open_set; neighbor]; %#ok<AGROW>
            end
        end
    end
end

path = [];

end