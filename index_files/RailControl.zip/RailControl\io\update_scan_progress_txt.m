function update_scan_progress_txt(filename, start_time, n_done, n_total, x_phys, y_phys)
% ================== update_scan_progress_txt.m ==================
% 根据开始时间、当前完成点数、总点数，实时估计剩余时间和完成时间，
% 并写入同步 txt 文件。
%
% 输入：
%   filename   : txt 文件完整路径
%   start_time : 扫描开始时间，datetime 类型
%   n_done     : 已完成点数
%   n_total    : 总点数
%   x_phys     : 当前测点 x 坐标
%   y_phys     : 当前测点 y 坐标

t_now = datetime('now');

if n_done <= 0
    elapsed_sec = NaN;
    remaining_sec = NaN;
    finish_time_est = NaT;
else
    elapsed_sec = seconds(t_now - start_time);

    avg_sec_per_point = elapsed_sec / n_done;
    n_left = n_total - n_done;

    remaining_sec = avg_sec_per_point * n_left;
    finish_time_est = t_now + seconds(remaining_sec);
end

fprintf('[%d/%d] elapsed = %s, remaining = %s, finish ~= %s\n', ...
    n_done, n_total, ...
    format_seconds_or_blank_local(elapsed_sec), ...
    format_seconds_or_blank_local(remaining_sec), ...
    datetime_to_string_or_blank_local(finish_time_est));

write_scan_progress_txt( ...
    filename, ...
    start_time, ...
    n_done, ...
    n_total, ...
    elapsed_sec, ...
    remaining_sec, ...
    finish_time_est, ...
    x_phys, ...
    y_phys);

end


function str = format_seconds_or_blank_local(t_sec)
% 把秒数格式化为 hh:mm:ss。
% 如果是 NaN，则返回 --:--:--。

if isnan(t_sec)
    str = '--:--:--';
    return;
end

t_sec = max(0, round(t_sec));

hh = floor(t_sec / 3600);
mm = floor(mod(t_sec, 3600) / 60);
ss = mod(t_sec, 60);

str = sprintf('%02d:%02d:%02d', hh, mm, ss);

end


function str = datetime_to_string_or_blank_local(t)
% datetime 转字符串。
% 如果是 NaT，则返回空白占位。

if isnat(t)
    str = '---- -- -- --:--:--';
else
    str = datestr(t, 'yyyy-mm-dd HH:MM:SS');
end

end