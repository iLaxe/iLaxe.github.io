function [is_bad, stats] = is_bad_signal(sig, qstep, max_levels, min_len, silent_p2p)
% ================== is_bad_signal.m ==================
% 基于“有限电平 + 静音 + 长度”的录音质量检测
%
% 输入：
%   sig         : 单通道信号向量
%   qstep       : 量化步长
%   max_levels  : 不同电平数 <= 该值时视为坏文件
%   min_len     : 最小有效长度
%   silent_p2p  : 峰峰值小于该值时视为静音
%
% 输出：
%   is_bad      : true 表示疑似坏录音
%   stats       : 检测统计信息

sig = sig(:);
N   = numel(sig);

stats = struct;
stats.N = N;
stats.p2p = NaN;
stats.n_levels = NaN;

%% 0) 空信号
if isempty(sig)
    is_bad = true;
    stats.p2p = NaN;
    stats.n_levels = NaN;
    return;
end

%% 1) 长度太短
if N < min_len
    is_bad = true;
    stats.p2p = max(sig) - min(sig);
    stats.n_levels = NaN;
    return;
end

%% 2) 有 NaN / Inf
if any(~isfinite(sig))
    is_bad = true;
    stats.p2p = max(sig(isfinite(sig))) - min(sig(isfinite(sig)));
    stats.n_levels = NaN;
    return;
end

%% 3) 静音检测：peak-to-peak 太小
p2p = max(sig) - min(sig);
stats.p2p = p2p;

if p2p < silent_p2p
    is_bad = true;
    stats.n_levels = NaN;
    return;
end

%% 4) 抽样统计电平数，避免长文件太慢
max_sample = 2e5;

if N > max_sample
    idx = randperm(N, max_sample);
    sig_sel = sig(idx);
else
    sig_sel = sig;
end

%% 5) 量化后统计不同电平数
sig_q    = round(sig_sel / qstep);
levels   = unique(sig_q);
n_levels = numel(levels);

stats.n_levels = n_levels;

%% 6) 电平数太少，视为异常
is_bad = n_levels <= max_levels;

end