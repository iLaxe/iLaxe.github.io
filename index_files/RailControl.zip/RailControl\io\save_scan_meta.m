function save_scan_meta(cfg, scan, audio_files, io)
% ================== save_scan_meta.m ==================
% 保存扫描实验的 meta 信息
%
% 输入：
%   cfg         : 实验配置结构体
%   scan        : 扫描网格与路径结构体
%   audio_files : wav 文件路径列表
%   io          : make_output_dirs 返回的结构体
%
% 输出：
%   scan_meta.txt
%   scan_meta.mat

%% 基本检查
if ~isfield(io, 'data_dir')
    error('io.data_dir 未设置');
end

if ~exist(io.data_dir, 'dir')
    mkdir(io.data_dir);
end

%% txt meta
txt_name = fullfile(io.data_dir, 'scan_meta.txt');

fid = fopen(txt_name, 'w');
if fid < 0
    error('无法创建 meta 文件：%s', txt_name);
end

fprintf(fid, 'Scan started       : %s\n', datestr(now, 31));

%% 采集模式
fprintf(fid, '\n[ACQUISITION]\n');

if isfield(cfg, 'acq') && isfield(cfg.acq, 'mode')
    fprintf(fid, 'acq_mode           : %s\n', string(cfg.acq.mode));
else
    fprintf(fid, 'acq_mode           : wav_record\n');
end

%% 音频信息
fprintf(fid, '\n[AUDIO]\n');

if isempty(audio_files)
    fprintf(fid, 'audio_files         : none\n');
else
    for i = 1:numel(audio_files)
        fprintf(fid, 'audio_file_%d       : %s\n', i, audio_files(i));
    end
end

if isfield(cfg, 'audio')
    if isfield(cfg.audio, 'use_segments')
        fprintf(fid, 'use_segments       : %d\n', cfg.audio.use_segments);
    else
        fprintf(fid, 'use_segments       : 0\n');
    end

    if isfield(cfg.audio, 'folder')
        fprintf(fid, 'audio_folder       : %s\n', cfg.audio.folder);
    end
    if isfield(cfg.audio, 'gain_dB')
        fprintf(fid, 'gain_dB            : %.2f\n', cfg.audio.gain_dB);
    end
    if isfield(cfg.audio, 'do_truncate')
        fprintf(fid, 'do_truncate        : %d\n', cfg.audio.do_truncate);
    end
    if isfield(cfg.audio, 'sig_duration')
        fprintf(fid, 'sig_duration_s     : %.4f\n', cfg.audio.sig_duration);
    end
end

%% segments 详细信息
fprintf(fid, '\n[AUDIO_SEGMENTS]\n');

if isfield(cfg, 'audio') && ...
        isfield(cfg.audio, 'use_segments') && cfg.audio.use_segments && ...
        isfield(cfg.audio, 'segments') && ~isempty(cfg.audio.segments)

    segments = cfg.audio.segments;
    fprintf(fid, 'num_segments       : %d\n', numel(segments));

    for i = 1:numel(segments)
        seg = segments{i};

        fprintf(fid, '\nsegment_%d\n', i);

        if isfield(seg, 'file')
            fprintf(fid, '  file             : %s\n', string(seg.file));
        end
        if isfield(seg, 'gain_dB')
            fprintf(fid, '  gain_dB          : %.4f\n', seg.gain_dB);
        end
        if isfield(seg, 'do_cut')
            fprintf(fid, '  do_cut           : %d\n', seg.do_cut);
        end
        if isfield(seg, 't_start')
            fprintf(fid, '  t_start_s        : %.6f\n', seg.t_start);
        end
        if isfield(seg, 't_dur')
            fprintf(fid, '  t_dur_s          : %.6f\n', seg.t_dur);
        end
    end
else
    fprintf(fid, 'num_segments       : 0\n');
end

%% 声卡信息
fprintf(fid, '\n[SOUNDCARD]\n');

if isfield(cfg, 'soundcard')
    if isfield(cfg.soundcard, 'fs')
        fprintf(fid, 'fs_Hz              : %d\n', cfg.soundcard.fs);
    end
    if isfield(cfg.soundcard, 'frmlen')
        fprintf(fid, 'frmlen             : %d\n', cfg.soundcard.frmlen);
    end
    if isfield(cfg.soundcard, 'driver')
        fprintf(fid, 'driver             : %s\n', cfg.soundcard.driver);
    end
    if isfield(cfg.soundcard, 'device')
        fprintf(fid, 'device             : %s\n', cfg.soundcard.device);
    end
    if isfield(cfg.soundcard, 'min_play_ch')
        fprintf(fid, 'min_play_ch        : %d\n', cfg.soundcard.min_play_ch);
    end
end

%% BK 参数
fprintf(fid, '\n[BK]\n');

if isfield(cfg, 'bk')
    if isfield(cfg.bk, 'funcs')
        fprintf(fid, 'funcs              : %s\n', mat2str(cfg.bk.funcs));
    end
    if isfield(cfg.bk, 'pause_after_move_s')
        fprintf(fid, 'pause_after_move_s : %.6f\n', cfg.bk.pause_after_move_s);
    end
    if isfield(cfg.bk, 'pause_between_segments_s')
        fprintf(fid, 'pause_between_segments_s : %.6f\n', cfg.bk.pause_between_segments_s);
    end
    if isfield(cfg.bk, 'output_prefix')
        fprintf(fid, 'output_prefix      : %s\n', string(cfg.bk.output_prefix));
    end
else
    fprintf(fid, 'bk_config          : none\n');
end

%% 扫描网格信息
fprintf(fid, '\n[SCAN]\n');

if isfield(cfg, 'scan')

    if isfield(cfg.scan, 'mode')
        fprintf(fid, 'scan_mode          : %s\n', cfg.scan.mode);
    end

    %% 声源位置标注
    if isfield(cfg.scan, 'source_xy')
        fprintf(fid, 'source_xy_m        : %.6f %.6f\n', ...
            cfg.scan.source_xy(1), cfg.scan.source_xy(2));
    end

    if all(isfield(cfg.scan, {'ax', 'ay', 'deltax', 'deltay'}))
        fprintf(fid, 'ax_ay_dx_dy_m      : %.4f %.4f %.4f %.4f\n', ...
            cfg.scan.ax, cfg.scan.ay, cfg.scan.deltax, cfg.scan.deltay);
    end

    if isfield(cfg.scan, 'custom') && isfield(cfg.scan.custom, 'xy')
        fprintf(fid, 'custom_num_pts     : %d\n', size(cfg.scan.custom.xy, 1));
        fprintf(fid, 'custom_xy_range_x  : %.6f %.6f\n', ...
            min(cfg.scan.custom.xy(:,1)), max(cfg.scan.custom.xy(:,1)));
        fprintf(fid, 'custom_xy_range_y  : %.6f %.6f\n', ...
            min(cfg.scan.custom.xy(:,2)), max(cfg.scan.custom.xy(:,2)));
        if isfield(cfg.scan.custom, 'tol')
            fprintf(fid, 'custom_tol_m       : %.6f\n', cfg.scan.custom.tol);
        end
    end

    if isfield(cfg.scan, 'forbidden_zones')
        fprintf(fid, 'num_forbidden_zone : %d\n', size(cfg.scan.forbidden_zones, 1));

        if ~isempty(cfg.scan.forbidden_zones)
            fprintf(fid, 'forbidden_zones    : [xmin xmax ymin ymax]\n');
            for k = 1:size(cfg.scan.forbidden_zones, 1)
                z = cfg.scan.forbidden_zones(k, :);
                fprintf(fid, 'zone_%d             : %.6f %.6f %.6f %.6f\n', ...
                    k, z(1), z(2), z(3), z(4));
            end
        end
    end

    %% circle 参数
    if isfield(cfg.scan, 'circle')
        if isfield(cfg.scan.circle, 'center')
            fprintf(fid, 'circle_center_xy_m : %.4f %.4f\n', ...
                cfg.scan.circle.center(1), cfg.scan.circle.center(2));
        end
        if isfield(cfg.scan.circle, 'radius')
            fprintf(fid, 'circle_radius_m    : %.4f\n', cfg.scan.circle.radius);
        end
        if isfield(cfg.scan.circle, 'N')
            fprintf(fid, 'circle_N           : %d\n', cfg.scan.circle.N);
        end
        if isfield(cfg.scan.circle, 'tol')
            fprintf(fid, 'circle_tol_m       : %.4f\n', cfg.scan.circle.tol);
        end
    end

    %% circle_2step 参数
    if isfield(cfg.scan, 'circle_2step')
        c2 = cfg.scan.circle_2step;

        if isfield(c2, 'theta_mid_deg')
            fprintf(fid, 'theta_mid_deg      : %.4f\n', c2.theta_mid_deg);
        end
        if isfield(c2, 'dtheta_mid_deg')
            fprintf(fid, 'dtheta_mid_deg     : %.4f\n', c2.dtheta_mid_deg);
        end
        if isfield(c2, 'dtheta_side_deg')
            fprintf(fid, 'dtheta_side_deg    : %.4f\n', c2.dtheta_side_deg);
        end
    end

    %% 坐标映射矩阵
    if isfield(cfg.scan, 'J')
        fprintf(fid, 'J                  :\n');
        fprintf(fid, '%.6f %.6f %.6f\n', cfg.scan.J.');
    end
end

%% scan 结构信息
fprintf(fid, '\n[SCAN_SEQUENCE]\n');

if isfield(scan, 'num_pts')
    fprintf(fid, 'num_pts            : %d\n', scan.num_pts);
end

if isfield(scan, 'nx') && isfield(scan, 'ny')
    fprintf(fid, 'nx_ny              : %d %d\n', scan.nx, scan.ny);
end

if isfield(scan, 'x_points') && ~isempty(scan.x_points)
    fprintf(fid, 'x_range_m          : %.6f %.6f\n', ...
        min(scan.x_points), max(scan.x_points));
end

if isfield(scan, 'y_points') && ~isempty(scan.y_points)
    fprintf(fid, 'y_range_m          : %.6f %.6f\n', ...
        min(scan.y_points), max(scan.y_points));
end

if isfield(scan, 'x0') && isfield(scan, 'y0')
    fprintf(fid, 'start_xy_m         : %.4f %.4f\n', scan.x0, scan.y0);
end

if isfield(scan, 'ix0') && isfield(scan, 'iy0')
    fprintf(fid, 'start_ix_iy        : %d %d\n', scan.ix0, scan.iy0);
end

%% 运动参数
fprintf(fid, '\n[MOTION]\n');

if isfield(cfg, 'motion')
    if isfield(cfg.motion, 'com_port')
        fprintf(fid, 'com_port           : %s\n', cfg.motion.com_port);
    end
    if isfield(cfg.motion, 'baudrate')
        fprintf(fid, 'baudrate           : %d\n', cfg.motion.baudrate);
    end
    if isfield(cfg.motion, 'timeout_s')
        fprintf(fid, 'timeout_s          : %.4f\n', cfg.motion.timeout_s);
    end
    if isfield(cfg.motion, 'max_speed_mm')
        fprintf(fid, 'max_speed_mm_s     : %.4f\n', cfg.motion.max_speed_mm);
    end
    if isfield(cfg.motion, 'accel_mmps2')
        fprintf(fid, 'accel_mmps2        : %.4f\n', cfg.motion.accel_mmps2);
    end
    if isfield(cfg.motion, 'set_speed_accel')
        fprintf(fid, 'set_speed_accel    : %d\n', cfg.motion.set_speed_accel);
    end
    if isfield(cfg.motion, 'move_timeout_s')
        fprintf(fid, 'move_timeout_s     : %.4f\n', cfg.motion.move_timeout_s);
    end
end

%% 运行模式
fprintf(fid, '\n[RUN]\n');

if isfield(cfg, 'run')
    if isfield(cfg.run, 'dry_run')
        fprintf(fid, 'dry_run            : %d\n', cfg.run.dry_run);
    end
else
    fprintf(fid, 'dry_run            : 0\n');
end

%% 播放录音参数
fprintf(fid, '\n[PLAYREC]\n');

if isfield(cfg, 'playrec')
    names = fieldnames(cfg.playrec);

    for i = 1:numel(names)
        val = cfg.playrec.(names{i});

        if isnumeric(val) || islogical(val)
            if isscalar(val)
                fprintf(fid, '%-20s : %.8g\n', names{i}, val);
            else
                fprintf(fid, '%-20s : %s\n', names{i}, mat2str(val));
            end
        elseif ischar(val) || isstring(val)
            fprintf(fid, '%-20s : %s\n', names{i}, string(val));
        end
    end
end

%% 保存路径
fprintf(fid, '\n[OUTPUT]\n');
fprintf(fid, 'data_dir           : %s\n', io.data_dir);

if isfield(io, 'prog_dir')
    fprintf(fid, 'prog_dir           : %s\n', io.prog_dir);
end

fclose(fid);

%% mat meta
mat_name = fullfile(io.data_dir, 'scan_meta.mat');

save(mat_name, ...
    'cfg', 'scan', 'audio_files', 'io');

fprintf('Meta saved:\n');
fprintf('  %s\n', txt_name);
fprintf('  %s\n', mat_name);

end