function scan_sequence = map_curve_to_grid(x_curve, y_curve, x_points, y_points, map, max_dist)
% ================== map_curve_to_grid.m ==================
% 将连续曲线坐标映射到最近的扫描网格点
%
% 输入：
%   x_curve, y_curve : 连续曲线点坐标
%   x_points         : 网格 x 坐标
%   y_points         : 网格 y 坐标
%   map              : 可扫描区域地图，1 可扫，0 禁区
%   max_dist         : 曲线点到最近网格点的最大允许距离
%
% 输出：
%   scan_sequence    : 扫描点序列，每行为 [iy, ix]

scan_sequence = [];
used_idx = [];

for i = 1:length(x_curve)

    x_real = x_curve(i);
    y_real = y_curve(i);

    [~, ix] = min(abs(x_points - x_real));
    [~, iy] = min(abs(y_points - y_real));

    x_grid = x_points(ix);
    y_grid = y_points(iy);

    if hypot(x_real - x_grid, y_real - y_grid) <= max_dist

        key = iy * 10000 + ix;

        if map(iy, ix) == 1 && ~ismember(key, used_idx)
            scan_sequence = [scan_sequence; iy, ix]; %#ok<AGROW>
            used_idx = [used_idx, key]; %#ok<AGROW>
        end
    end
end

end